package com.cg.product.service;

import java.util.List;

import com.cg.product.beans.Product;
import com.cg.product.dao.IProductDAO;
import com.cg.product.dao.ProductDAOImpl;

public class ProductServiceImpl implements IProductService {

	IProductDAO productDAO;
	
	public ProductServiceImpl() {
		productDAO = new ProductDAOImpl();
	}
	
	@Override
	public List<Product> getAllProducts() {
		return productDAO.getAllProducts();
	}

	@Override
	public Product addProduct(Product product) {
		return productDAO.addProduct(product);
	}

	@Override
	public Product deleteProduct(int productId) {
		return productDAO.deleteProduct(productId);
	}

}
