package com.cg.product.staticdb;

import java.util.HashMap;

import com.cg.product.beans.Product;


public class ProductDB {
	static HashMap<Integer, Product> productIdMap = getProductIdMap();
	
	static {
		if (productIdMap == null) {
			productIdMap = new HashMap<Integer, Product>();
			Product beautyProduct = new Product(1, "Cream", 100.25);
			Product elecProduct = new Product(4, "Bulb", 50.25);
			Product electProduct = new Product(3, "DVD", 400.00);
			Product decProduct = new Product(2, "Ribbon", 25.50);

			productIdMap.put(1, beautyProduct);
			productIdMap.put(4, elecProduct);
			productIdMap.put(3, electProduct);
			productIdMap.put(2, decProduct);
		}

	}
	
	public static HashMap<Integer, Product> getProductIdMap() {
		return productIdMap;
	}
}
