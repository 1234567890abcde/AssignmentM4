package com.cg.product.dao;

import java.util.List;

import com.cg.product.beans.Product;

public interface IProductDAO {
	public List<Product> getAllProducts();
	public Product addProduct(Product product);
	public Product deleteProduct(int productId);
}
