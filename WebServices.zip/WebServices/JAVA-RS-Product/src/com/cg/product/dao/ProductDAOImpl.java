package com.cg.product.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.product.beans.Product;
import com.cg.product.staticdb.ProductDB;

public class ProductDAOImpl implements IProductDAO {
	
	static HashMap<Integer, Product> productIdMap = ProductDB.getProductIdMap();

	@Override
	public List<Product> getAllProducts() {
		List<Product> products = new ArrayList<Product>(productIdMap.values());
		return products;
	}

	@Override
	public Product addProduct(Product product) {
		productIdMap.put(product.getProductId(), product);
		return product;
	}

	@Override
	public Product deleteProduct(int productId) {
		return productIdMap.remove(productId);
	}

}
