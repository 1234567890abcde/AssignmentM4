package com.cg.product.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.product.beans.Product;
import com.cg.product.service.IProductService;
import com.cg.product.service.ProductServiceImpl;

@Path("/products")
public class ProductController {

	IProductService productService = new ProductServiceImpl();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProducts() {
		List<Product> listOfProducts = productService.getAllProducts();
		return listOfProducts;
	}

	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product addProduct(@FormParam("productId") int productId,
			@FormParam("productName") String productName,
			@FormParam("productPrice") double productPrice) {
		Product product = new Product();
		product.setProductId(productId);
		product.setProductName(productName);
		product.setProductPrice(productPrice);
		return productService.addProduct(product);
		
	}
	
	@POST
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Product deleteProduct(@FormParam("productId") int productId) {
		Product product = productService.deleteProduct(productId);
		if(product!=null){
			return product;
		}else{
			return new Product();
		}
	}
}
