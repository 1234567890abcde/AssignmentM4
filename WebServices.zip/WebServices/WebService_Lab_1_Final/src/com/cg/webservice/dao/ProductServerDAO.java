package com.cg.webservice.dao;

public interface ProductServerDAO {
	
	public double getProduct(String pname);

}
