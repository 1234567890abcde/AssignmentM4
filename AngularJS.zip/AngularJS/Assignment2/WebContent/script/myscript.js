var myapp = angular.module("myapp", []);

myapp.controller("empctrl", function($scope) {
	
	$scope.employees = [ {
		empID : '810012',
		empName : 'Rahul',
		empLocation : 'Pune'
	}, {
		empID : '654123',
		empName : 'Uma',
		empLocation : 'Bangalore'
	}, {
		empID : '512014',
		empName : 'Yukti',
		empLocation : 'Pune'
	}, {
		empID : '251914',
		empName : 'Zanib',
		empLocation : 'Bangalore'
	}, {
		empID : '751124',
		empName : 'Kavita',
		empLocation : 'Mumbai'
	}, {
		empID : '151914',
		empName : 'Tanmya',
		empLocation : 'Bangalore'
	}, {
		empID : '251914',
		empName : 'Vaishali',
		empLocation : 'Pune'
	}, {
		empID : '221214',
		empName : 'Hema',
		empLocation : 'Chennai'
	}, {
		empID : '351914',
		empName : 'Anju',
		empLocation : 'Pune'
	}, {
		empID : '451124',
		empName : 'Vinod',
		empLocation : 'Pune'
	}, {
		empID : '11914',
		empName : 'Bharti',
		empLocation : 'Mumbai'
	} ];


});