var myapp = angular.module("myapp",[]);

myapp.controller("empctrl", function($scope) {
	$scope.employees = [ {
		empFirstName : 'Rahul',
		empLastName : 'Vikash',
		empEmail : 'rahul.vikash@capgemini.com',
		Selected: false
	}, {
		empFirstName : 'Uma',
		empLastName : 'Ponniamman',
		empEmail : 'Uma.Ponniamman@capgemini.com',
		Selected: false
	}, {
		empFirstName : 'Yukti',
		empLastName : 'Vikash',
		empEmail : 'Yukti.vikash@capgemini.com',
		Selected: false
	} ];
	
	$scope.addNew = function(){
		var employee=[];
		employee.empFirstName=$scope.empFirstName;
		employee.empLastName=$scope.empLastName;
		employee.empEmail=$scope.empEmail;
		employee.Selected=false;
		$scope.employees.push(employee);
		
		$scope.empFirstName="";
		$scope.empLastName="";
		$scope.empEmail="";
	};
	
	$scope.remove = function(){
		for(var i=0; i<$scope.employees.length;i++){
			if($scope.employees[i].Selected){
				var index = $scope.employees.indexOf($scope.employees[i]);
				 $scope.employees.splice(index,1);
			}
		}
	};
});